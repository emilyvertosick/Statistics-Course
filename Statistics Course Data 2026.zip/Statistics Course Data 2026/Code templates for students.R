# Installing packages
# This only needs to be done once - to install the packages, remove the "#"
# from in front of the code below. It is recommended to replace the "#"
# once the packages have been installed so this code does not run more than once.

# install.packages("tidyverse")
# install.packages("here")
# install.packages("skimr")
# remotes::install_version("epiR", version = "2.0.33", repos = "https://cloud.r-project.org")
# install.packages("broom")
# install.packages("pROC")
# install.packages("gmodels")
# install.packages("survival")
# install.packages("ggsurvfit")
# install.packages("gt")
# install.packages("cardx")
# install.packages("broom.helpers")

#***********************************************************************
# REMEMBER: YOU ALWAYS HAVE TO START BY LOADING PACKAGES
#***********************************************************************

# load packages
library(skimr)
library(gt)
library(gtsummary)
library(epiR)
library(broom)
library(pROC)
library(gmodels)
library(survival)
library(here)
library(tidyverse)

#***********************************************************************
# WE WILL USE THE DATA SETS FROM WEEK 1 TO LOOK AT BASIC DESCRIPTIVE STATISTICS
# AND BASIC DATA MANIPULATION
#***********************************************************************

# Week 1: load data
lesson1a <- readRDS(here::here("Data", "Week 1", "lesson1a.rds"))
lesson1b <- readRDS(here::here("Data", "Week 1", "lesson1b.rds"))
lesson1c <- readRDS(here::here("Data", "Week 1", "lesson1c.rds"))
lesson1d <- readRDS(here::here("Data", "Week 1", "lesson1d.rds"))
lesson1e <- readRDS(here::here("Data", "Week 1", "lesson1e.rds"))
lesson1f <- readRDS(here::here("Data", "Week 1", "lesson1f.rds"))

# "skim" provides summary statistics for all variables, or just one, in this case, age
skim(lesson1a)
skim(lesson1a$age)

# "tbl_summary" is creates nicely formatted tables, ready for publication
tbl_summary(
  lesson1a %>% select(sex),
)

# if you want a row for each category
tbl_summary(
  lesson1a %>% select(sex),
  type = list(sex = "categorical")
)

# if you want multiple categorical variables 
tbl_summary(
  lesson1a %>% select(sex, y),
)

# if you want to relabel a variable: here variable "y" is the location
# so let's make that clear
attr(lesson1a$y, "label") <- "Location of surgery"

# or make it clearer still by renaming it!
# rename a variable
lesson1a <-
  lesson1a %>%
  rename(location = y)

# You can also change the label within a table, so that it looks good 
tbl_summary(
  lesson1a %>% select(sex, location),
  label = list(sex = "Women", location = "Campus")
)

# For categorical variables, we might want to change the labels. 
# For instance, in your published paper, you'd want "peds" to say "Pediatrics"
# you can do this using "mutate" and "case_when"

lesson1a <-
  lesson1a %>%
  mutate(
    location =
      case_when(
        location == "campus" ~ "Main Campus",
        location == "harding" ~ "Harding",
        location == "peds" ~ "Pediatric",
        location == "satellite" ~ "Satellite"
      )
  )

# If you only want to look at part of a data set
# Here we are excluding patients with high-stage disease

# we will load up a data set called "trial" that is used for examples
trial

# exclude T3 and T4
trial %>%
  filter(stage != "T3" & stage != "T4")

# Print original dataset to confirm no changes
trial

# Save out a new dataset including only T1 and T2 patients
trial_localized <-
  trial %>%
  filter(stage != "T3" & stage != "T4")

# You'll see that there are no T3 or T4 cases in this data set
trial_localized

# Summary statistics separately by another variable, e.g. sex
lesson1b %>%
  group_by(sex) %>%
  skim(rt)

# Creating a histogram, "bins" is how many bars you want on the histogram
ggplot(data = lesson1c,
       aes(x = t)) +
  geom_histogram(bins = 20)

# Creating a new variable, in this case a variable for log of the pain score
lesson1f <-
  lesson1f %>%
  mutate(log = log(pain))

# Creating a new categorical variables to combine different categories into 1
lesson1d <-
  lesson1d %>%
  mutate(
    stage_category =
      case_when(
        stage %in% c("T1A", "T1B", "T1C") ~ "T1",
        stage %in% c("T3", "T4") ~ "T3/4",
        TRUE ~ stage
      )
  )

#***********************************************************************
# FOR BASIC INFERENCE STATISTICS LIKE T-TEST, WE WILL LOAD UP THE DATA FROM LESSON 2
#***********************************************************************

# Week 2: load data
lesson2a <- readRDS(here::here("Data", "Week 2", "lesson2a.rds"))
lesson2b <- readRDS(here::here("Data", "Week 2", "lesson2b.rds"))
lesson2c <- readRDS(here::here("Data", "Week 2", "lesson2c.rds"))
lesson2d <- readRDS(here::here("Data", "Week 2", "lesson2d.rds"))
lesson2e <- readRDS(here::here("Data", "Week 2", "lesson2e.rds"))
lesson2f <- readRDS(here::here("Data", "Week 2", "lesson2f.rds"))

# t-test comparing intensity of nausea/vomiting by
# whether patient had prior chemotherapy
# these are two separate groups, so the data are "unpaired"
t.test(nv ~ pc, data = lesson2a, var.equal = TRUE)

# paired t-test, here comparing day 1 and day 2 pain
t.test(lesson2c$t1, lesson2c$t2, paired = TRUE, var.equal = TRUE)

# Non-parametric paired test, here comparing day 1 and day 2 pain
wilcox.test(lesson2c$t1, lesson2c$t2, paired = TRUE)

# Test a proportion against a hypothesized value
# in this case whether proportion of women is different from 50%
binom.test(sum(lesson2d$sex), nrow(lesson2d %>% filter(!is.na(sex))), p = 0.5)

# test a continuous variable against a hypothesized variable
# here, whether age is significantly different from 58.2
t.test(lesson2d$age, mu = 58.2)

#***********************************************************************
# FOR TESTS FOR CATEGORICAL VARIABLES, WE WILL LOAD UP THE DATA FROM LESSON 3
#***********************************************************************

# Week 3: load data
lesson3a <- readRDS(here::here("Data", "Week 3", "lesson3a.rds"))
lesson3b <- readRDS(here::here("Data", "Week 3", "lesson3b.rds"))
lesson3c <- readRDS(here::here("Data", "Week 3", "lesson3c.rds"))
lesson3d <- readRDS(here::here("Data", "Week 3", "lesson3d.rds"))
lesson3e <- readRDS(here::here("Data", "Week 3", "lesson3e.rds"))

# Chi squared test for a two by two table of nausea and car sickness, with no continuity correction 
chisq.test(table(lesson3a$nv, lesson3a$cs), correct = FALSE)

# a two-way table
tbl_summary(
  lesson3a %>% select(nv, cs),
  by = cs,
  type = list(nv = "categorical")
)

# Fisher's exact test for a 2 by 2 table, useful when cell sizes are low
fisher.test(table(lesson3a$nv, lesson3a$cs))

# Confidence interval for difference between groups
epi.2by2(
  table(
    factor(lesson3a$cs, levels = c(1, 0)),
    factor(lesson3a$nv, levels = c(1, 0))
  )
)

# 95% CI for absolute risk difference
prop.test(table(lesson3a$cs, lesson3a$nv), correct = FALSE)

# Formatted table that gives row percentages
tbl_summary(
  lesson3b %>% select(meat, hbp),
  by = hbp,
  percent = "row"
)

# Create a binary variable depending on the values of another variable
lesson3c <-
  lesson3c %>%
  mutate(
    mutant =
      case_when(
        gene == 1 | gene == 2 ~ 1,
        gene == 0 ~ 0
      )
  )

# You can use the "filter" function to split your data into subgroups

# For males (sex = 0)
lesson3d_males <-
  lesson3d %>%
  filter(sex == 0)

# To confirm:
table(lesson3d_males$sex)

# For females
lesson3d_females <-
  lesson3d %>%
  filter(sex == 1)

# To confirm:
table(lesson3d_females$sex)

#***********************************************************************
# FOR TESTS FOR CATEGORICAL VARIABLES, WE WILL LOAD UP THE DATA FROM LESSON 4
#***********************************************************************

# Week 4: load data
lesson4a <- readRDS(here::here("Data", "Week 4", "lesson4a.rds"))
lesson4b <- readRDS(here::here("Data", "Week 4", "lesson4b.rds"))
lesson4c <- readRDS(here::here("Data", "Week 4", "lesson4c.rds"))
lesson4d <- readRDS(here::here("Data", "Week 4", "lesson4d.rds"))
lesson4e <- readRDS(here::here("Data", "Week 4", "lesson4e.rds"))
lesson4f <- readRDS(here::here("Data", "Week 4", "lesson4f.rds"))
lesson4g <- readRDS(here::here("Data", "Week 4", "lesson4g.rds"))
lesson4h <- readRDS(here::here("Data", "Week 4", "lesson4h.rds"))
lesson4i <- readRDS(here::here("Data", "Week 4", "lesson4i.rds"))

# Create multivariable linear regression model for race time
rt_model <- lm(rt ~ age + sex + tr + wt, data = lesson4a)

# Results of linear regression model
summary(rt_model)

# Create logistic regression model
mutate_model <- glm(mutation ~ c, data = lesson4b, family = "binomial")

# Formatted results with odds ratios
tbl_regression(mutate_model, exponentiate = TRUE)

# Formatted results in logits
# The "intercept = TRUE" option includes the constant in the table
tbl_regression(mutate_model,
               exponentiate = FALSE,
               intercept = TRUE)

# Use "filter" to exclude patients with outlying values, here, high disease duration
lesson4b <-
  lesson4b %>%
  filter(c <= 50)

# Create predictions
lesson4b_pred <-
  augment(mutate_model,
          type.predict = "response")

# A two-way plot
# Tells the plot what data to use, and what variables correspond
# to the x and y axes
ggplot(data = lesson4b_pred, aes(x = c, y = .fitted)) +
  # Creates the line portion of the graph
  geom_line() +
  # Creates the points along the line
  geom_point() +
  # Labels the x and y axes
  labs(
    x = "Disease duration",
    y = "Risk of mutation"
  )

# Remove the observation for all of Canada from dataset
lesson4c_fixed <-
  lesson4c %>%
  filter(place != "Canada")

# Calculate correlation, in this case. between unemployment and male/female life expectancy
# There are missing values for unemployment,
# so we need to indicate that we only want to use "complete observations"
cor(lesson4c_fixed %>% select(unemp, mlife, flife),
    use = "complete.obs")

# Create multivariable logistic regression model and show the table
cam_model1 <- glm(CAM ~ age + t + mets + u + q18 + e + m + ses,
                  data = lesson4e,
                  family = "binomial")
tbl_regression(cam_model1, exponentiate = TRUE)


# Create tables separately for different values of a variable. In this case, sex
# For men
tbl_summary(
  lesson4g %>% filter(sex == 0) %>% select(response, chemo),
  by = chemo,
  type = list(response = "categorical")
)

# For women
tbl_summary(
  lesson4g %>% filter(sex == 1) %>% select(response, chemo),
  by = chemo,
  type = list(response = "categorical")
)

# Create logistic regression model for response including interaction between sex and chemo
sex_int_model <- glm(response ~ sex + chemo + sex*chemo,
                     data = lesson4g,
                     family = "binomial")

# Get AUC of a model
# First, get predicted probabilities from final model
final_model_pred <-
  augment(final_model, type.predict = "response")

# Then get AUC
roc(cancer ~ .fitted, data = final_model_pred)

#***********************************************************************
# FOR MORE ON REGRESSION, WE WILL LOAD UP THE DATA FROM LESSON 5D
#***********************************************************************
 
lesson5d <- readRDS(here::here("Data", "Week 5", "lesson5d.rds"))

# Create a model where a predictor is categorical
# "grade" is a categorical variable, so use "factor()"
recur_model <- glm(recurrence ~ stage + factor(grade_numeric),
                   data = lesson5d,
                   family = "binomial")

# Get the predicted probability for each patient
lesson5d_pred <-
  augment(
    recur_model,
    newdata = lesson5d,
    type.predict = "response",
    se = TRUE
  ) %>%
  # Renaming to identify each prediction separately
  rename(clinpred = .fitted, clinpred_se = .se.fit)

#***********************************************************************
# FOR SURVIVAL ANALYSIS, WE WILL LOAD UP THE DATA FROM LESSON 6
#***********************************************************************

# Week 6: load data
lesson6a <- readRDS(here::here("Data", "Week 6", "lesson6a.rds"))
lesson6b <- readRDS(here::here("Data", "Week 6", "lesson6b.rds"))
lesson6c <- readRDS(here::here("Data", "Week 6", "lesson6c.rds"))
lesson6d <- readRDS(here::here("Data", "Week 6", "lesson6d.rds"))

# Create survival outcome for time to death
lesson6a_surv <- Surv(lesson6a$survival_time, lesson6a$died)

# Median followup for all patients
survfit(lesson6a_surv ~ 1)

# Median followup for survivors
lesson6a %>%
  filter(died == 0) %>%
  skim(survival_time)

# Look at number of recurrence events in this dataset
survfit(Surv(lesson6a$survival_time, lesson6a$died) ~ 1)

# Multivariable Cox model for time to death
coxph(lesson6a_surv ~ sex + age + obstruction + perforation + adhesions + nodes,
      data = lesson6a) %>%
  tbl_regression(exponentiate = TRUE)

# Test for difference in time to recurrence 
survdiff(Surv(lesson6b$time, lesson6b$recurrence) ~ lesson6b$hivolume)

# Estimate survival at 6, 12 and 18 months
summary(survfit(Surv(lesson6b$time, lesson6b$recurrence) ~ lesson6b$hivolume),
        times = c(183, 365, 548))

tbl_survfit(survfit(Surv(lesson6b$time, lesson6b$recurrence) ~ lesson6b$hivolume),
        times = c(183, 365, 548))

# Create Kaplan-Meier plot by treatment group
ggsurvfit::survfit2(Surv(survival_time/365.25, died) ~ treatment, data = lesson6c) %>%
  ggsurvfit::ggsurvfit() +
  labs(
    x = "Survival Time (Years)"
  ) +
  scale_y_continuous(label = scales::percent)

# Create dummy variable for treatment
lesson6c <-
  lesson6c %>%
  mutate(
    fu = if_else(group == 2, 1, 0),
    lev = if_else(group == 3, 1, 0)
  )

# Cox model with dummy variables
coxph(Surv(survival_time, died) ~ fu + lev, data = lesson6c)

# Overall p value for all 3 groups
survdiff(Surv(survival_time, died) ~ group, data = lesson6c)

