# Installing packages
# This only needs to be done once - to install the packages, remove the "#"
# from in front of the code below. It is recommended to replace the "#"
# once the packages have been installed so this code does not run more than once.

# install.packages("tidyverse")
# install.packages("here")
# install.packages("skimr")
# install.packages("epiR")
# install.packages("broom")
# install.packages("pROC")
# install.packages("gmodels")
# install.packages("survival")
# install.packages("survminer")
# install.packages("remotes")
# remotes::install_github("rstudio/gt")
# install.packages("gtsummary")


#***************************************************************************
#REMEMBER: YOU ALWAYS HAVE TO START BY LOADING PACKAGES
#***************************************************************************



# load packages
library(skimr)
library(gt)
library(gtsummary)
library(epiR)
library(broom)
library(pROC)
library(gmodels)
library(survival)
library(here)
library(tidyverse)





#***************************************************************************
# WE WILL USE THE DATA SETS FROM WEEK 1 TO LOOK AT BASIC DESCRIPTIVE STATISTICS
# AND BASIC DATA MANIPULATION
#***************************************************************************

#  load data
lesson1a <- readRDS(here::here("Data", "Week 1", "lesson1a.rds"))

# "skim" provides summary statistics for all variables, or just one, in this case, age
skim(lesson1a)
skim(lesson1a$age)

# "tbl_summary" is creates nicely formatted tables, ready for publication
tbl_summary(
  lesson1a %>% select(sex),
)

# if you want a row for each category
tbl_summary(
  lesson1a %>% select(sex),
  type= list("sex" ~ "categorical")
)

# if you want a multiple categorical variables 
tbl_summary(
  lesson1a %>% select(sex, y),
)

# if you want to relabel a variable: here variable "y" is the location
# so let's make that clear
attr(lesson1a$y, "label") <- "Location of surgery"

#or make it clearer still by renaming it!
# rename a variable
lesson1a <-
  lesson1a %>%
  rename(location = y)

# You can also change the label within a table, so that it looks good 
tbl_summary(
  lesson1a %>% select(sex, location),
  label = list("sex" ~ "Women", "location" ~ "Campus")
)

# For categorical variables, we might want to change the labels. 
# For instance, in your published paper, you'd want "peds" to say "Pediatrics"
#  you can do this using "mutate" and "case_when"

lesson1a <-
  lesson1a %>%
  mutate(
    location =
      case_when(
        location == "campus" ~ "Main Campus",
        location == "harding" ~ "Harding",
        location == "peds" ~ "Pediatric",
        location == "satellite" ~ "Satellite"
      )
  )

# If you only want to look at part of a data set
# Here we are excluding patients with high-stage disease

# we will load up a data set called "trial" that is used for examples
trial

# exclude T3 and T4
trial %>%
  filter(stage != "T3" & stage != "T4")

# Print original dataset to confirm no changes
trial

# Save out a new dataset including only T1 T2 patients
trial_localized <-
  trial %>%
  filter(stage != "T3" & stage != "T4")

#You'll see that there are no T3 or T4 cases in this data set
trial_localized


#***************************************************************************
# FOR MORE SUMMARY STATISTICS, WE WILL LOAD UP THE DATA FROM LESSON 2
#***************************************************************************


# Week 2: load data
lesson2a <- readRDS(here::here("Data", "Week 2", "lesson2a.rds"))
lesson2b <- readRDS(here::here("Data", "Week 2", "lesson2b.rds"))
lesson2c <- readRDS(here::here("Data", "Week 2", "lesson2c.rds"))
lesson2d <- readRDS(here::here("Data", "Week 2", "lesson2d.rds"))
lesson2e <- readRDS(here::here("Data", "Week 2", "lesson2e.rds"))

# Summary statistics separately by another variable, e.g. sex
lesson2a %>%
  group_by(sex) %>%
  skim(rt)

# Creating a histogram, "Bins" is how many bars you want on the histogram
ggplot(data = lesson2b,
       aes(x = t)) +
  geom_histogram(bins=20)

# Creating a new variable, in this case a variable for log of the pain score
lesson2e <-
  lesson2e %>%
  mutate(log = log(pain))


# Creating a new categorical variables to combine different categories into 1
lesson2c <-
  lesson2c %>%
  mutate(
    stage_category =
      case_when(
        stage %in% c("T1A", "T1B", "T1C") ~ "T1",
        stage %in% c("T3", "T4") ~ "T3/4",
        TRUE ~ stage
      )
  )


#***************************************************************************
# FOR BASIC INFERENCE STATISTICS LIKE T-TEST, WE WILL LOAD UP THE DATA FROM LESSON 2
#***************************************************************************



# Week 3: load data
lesson3a <- readRDS(here::here("Data", "Week 3", "lesson3a.rds"))
lesson3b <- readRDS(here::here("Data", "Week 3", "lesson3b.rds"))
lesson3c <- readRDS(here::here("Data", "Week 3", "lesson3c.rds"))
lesson3d <- readRDS(here::here("Data", "Week 3", "lesson3d.rds"))
lesson3e <- readRDS(here::here("Data", "Week 3", "lesson3e.rds"))
lesson3f <- readRDS(here::here("Data", "Week 3", "lesson3f.rds"))

# t-test comparing intensity of nausea/vomiting by
# whether patient had prior chemotherapy
# these are two separate groups, so the data are "unpaired"

t.test(nv ~ pc, data = lesson3a, paired = FALSE, var.equal = TRUE)

# paired t-test, here comparing day 1 and day 2 pain
t.test(lesson3c$t1, lesson3c$t2, paired = TRUE, var.equal = TRUE)

# Non-parametric paired test, here comparing day 1 and day 2 pain
wilcox.test(lesson3c$t1, lesson3c$t2, paired = TRUE)




# Test a proportion against a hypothesized value
# in this case whether proportion of women is different from 50%
binom.test(sum(lesson3d$sex), nrow(lesson3d %>% filter(!is.na(sex))), p = 0.5)

# test a continuous variable against a hypothesized variable
# here  whether age is significantly different from 58.2
t.test(lesson3d$age, mu = 58.2)


#***************************************************************************
# FOR TESTS FOR CATEGORICAL VARIABLES, WE WILL LOAD UP THE DATA FROM LESSON 4
#***************************************************************************

# Week 4: load data
lesson4a <- readRDS(here::here("Data", "Week 4", "lesson4a.rds"))
lesson4b <- readRDS(here::here("Data", "Week 4", "lesson4b.rds"))
lesson4c <- readRDS(here::here("Data", "Week 4", "lesson4c.rds"))
lesson4d <- readRDS(here::here("Data", "Week 4", "lesson4d.rds"))
lesson4e <- readRDS(here::here("Data", "Week 4", "lesson4e.rds"))


# Chi squared test for a two by two table of nause and car sickness. 
chisq.test(table(lesson4a$nv, lesson4a$cs))


# a two-way table
tbl_summary(
  lesson4a %>% select(nv, cs),
  by = cs,
  type = list("nv" ~ "categorical")
)

# Fisher's exact test for a 2 by 2 table, useful when cell sizes are low
fisher.test(table(lesson4a$nv, lesson4a$cs))

# Confidence interval for difference between groups
epi.2by2(matrix(rev(table(lesson4a$cs, lesson4a$nv)), nrow = 2))

# 95% CI for absolute risk difference
prop.test(table(lesson4a$cs, lesson4a$nv), correct = FALSE)


# Formatted table that gives row percentages
tbl_summary(
  lesson4b %>% select(meat, hbp),
  by = hbp,
  percent = "row"
)



# Create a binary variable depending on the values of another variable
lesson4c <-
  lesson4c %>%
  mutate(
    mutant =
      case_when(
        gene == 1 | gene == 2 ~ 1,
        gene == 0 ~ 0
      )
  )

# You can use the "group_split" function to split your dataset into two groups
lesson4d_sex <-
  lesson4d %>%
  group_split(sex)

# The first dataset, indicated by lesson4d_sex[[1]], is males
lesson4d_males <- lesson4d_sex[[1]]

# To confirm:
table(lesson4d_males$sex)

# The second dataset, indicated by lesson4d_sex[[2]], is females
lesson4d_females <- lesson4d_sex[[2]]

#***************************************************************************
# FOR TESTS FOR CATEGORICAL VARIABLES, WE WILL LOAD UP THE DATA FROM LESSON 5
#***************************************************************************



# Week 5: load data
lesson5a <- readRDS(here::here("Data", "Week 5", "lesson5a.rds"))
lesson5b <- readRDS(here::here("Data", "Week 5", "lesson5b.rds"))
lesson5c <- readRDS(here::here("Data", "Week 5", "lesson5c.rds"))
lesson5d <- readRDS(here::here("Data", "Week 5", "lesson5d.rds"))
lesson5e <- readRDS(here::here("Data", "Week 5", "lesson5e.rds"))
lesson5f <- readRDS(here::here("Data", "Week 5", "lesson5f.rds"))
lesson5g <- readRDS(here::here("Data", "Week 5", "lesson5g.rds"))
lesson5h <- readRDS(here::here("Data", "Week 5", "lesson5h.rds"))
lesson5i <- readRDS(here::here("Data", "Week 5", "lesson5i.rds"))

# Create multivariable linear regression model for race time
rt_model <- lm(rt ~ age + sex + tr + wt, data = lesson5a)

# Results of linear regression model
summary(rt_model)


# Create logistic regression model
mutate_model <- glm(mutation ~ c, data = lesson5b, family = "binomial")

# Formatted results with odds ratios
tbl_regression(mutate_model, exponentiate = TRUE)

# Formatted results in logits
# The "intercept = TRUE" option includes the constant in the table
tbl_regression(mutate_model,
               exponentiate = FALSE,
               intercept = TRUE)

# Use "filter" to exclude patients with outlying values, here, high disease duration
lesson5b <-
  lesson5b %>%
  filter(c <= 50)


# Create predictions
lesson5b_pred <-
  augment(mutate_model,
          type.predict = "response")


# A two-way plot
# Tells the plot what data to use, and what variables correspond
# to the x and y axes
ggplot(data = lesson5b_pred, aes(x = c, y = .fitted)) +
  # Creates the line portion of the graph
  geom_line() +
  # Creates the points along the line
  geom_point() +
  # Labels the x and y axes
  labs(
    x = "Disease duration",
    y = "Risk of mutation"
  )



# Calculate correlation, in this case. between unemployment and male/female life expectancy
# There are missing values for unemployment,
# so we need to indicate that we only want to use "complete observations"
cor(lesson5c_fixed %>% select(unemp, mlife, flife),
    use = "complete.obs")


# Create multivariable logistic regression model and show the table
cam_model1 <- glm(CAM ~ age + t + mets + u + q18 + e + m + ses,
                  data = lesson5e,
                  family = "binomial")
tbl_regression(cam_model1, exponentiate = TRUE)


# Create tables separately for different values of a variable. In this case, sex
# For men
tbl_summary(
  lesson5g %>% filter(sex == 0) %>% select(response, chemo),
  by = chemo,
  type = list("response" ~ "categorical")
)

# For women
tbl_summary(
  lesson5g %>% filter(sex == 1) %>% select(response, chemo),
  by = chemo,
  type = list("response" ~ "categorical")
)



# Create logistic regression model for response including interaction between sex and chemo
sex_int_model <- glm(response ~ sex + chemo + sex*chemo,
                     data = lesson5g,
                     family = "binomial")

# Get AUC of a model
# First, get predicted probabilities from final model
final_model_pred <-
  augment(final_model, type.predict = "response")
#Then get AUC
roc(cancer ~ .fitted, data = final_model_pred)

#***************************************************************************
# FOR MORE ON REGRESSION, WE WILL LOAD UP THE DATA FROM LESSON 6D
#***************************************************************************
 

lesson6d <- readRDS(here::here("Data", "Week 6", "lesson6d.rds"))



# Create a model where a predictor is categorical
# "grade" is a categorical variable, so use "factor()"
recur_model <- glm(recurrence ~ stage + factor(grade_numeric),
                   data = lesson6d,
                   family = "binomial")

# Get the predicted probability for each patient
lesson6d_pred <-
  augment(
    recur_model,
    newdata = lesson6d,
    type.predict = "response"
  ) %>%
  # Renaming to identify each prediction separately
  rename(clinpred = .fitted, clinpred_se = .se.fit)


#***************************************************************************
# FOR SURVIVAL ANALYSIS, WE WILL LOAD UP THE DATA FROM LESSON 7
#***************************************************************************


# Week 7: load data
lesson7a <- readRDS(here::here("Data", "Week 7", "lesson7a.rds"))
lesson7b <- readRDS(here::here("Data", "Week 7", "lesson7b.rds"))
lesson7c <- readRDS(here::here("Data", "Week 7", "lesson7c.rds"))
lesson7d <- readRDS(here::here("Data", "Week 7", "lesson7d.rds"))

# Create survival outcome for time to death
lesson7a_surv <- Surv(lesson7a$survival_time, lesson7a$died)

# Median followup for all patients
survfit(lesson7a_surv ~ 1)

# Median followup for survivors
lesson7a %>%
  filter(died == 0) %>%
  skim(survival_time)

# Look at number of recurrence events in this dataset
survfit(Surv(lesson7a$survival_time, lesson7a$died) ~ 1)

# Multivariable Cox model for time to death
coxph(lesson7a_surv ~ sex + age + obstruction + perforation + adhesions + nodes,
      data = lesson7a) %>%
  tbl_regression(exponentiate = TRUE)


# Test for difference in time to recurrence 
survdiff(Surv(lesson7b$time, lesson7b$recurrence) ~ lesson7b$hivolume)


# Estimate survival at 6, 12 and 18 months
summary(survfit(Surv(lesson7b$time, lesson7b$recurrence) ~ lesson7b$hivolume),
        times = c(183, 365, 548))



# Create Kaplan-Meier plot by treatment group
survminer::ggsurvplot(survfit(Surv(survival_time/365.25, died) ~ treatment, data = lesson7c),
                      legend = "bottom")

# Create dummy variable for treatment
lesson7c <-
  lesson7c %>%
  mutate(
    fu = if_else(group == 2, 1, 0),
    lev = if_else(group == 3, 1, 0)
  )

# Cox model with dummy variables
coxph(Surv(survival_time, died) ~ fu + lev, data = lesson7c)

# Overall p value for all 3 groups
survdiff(Surv(survival_time, died) ~ group, data = lesson7c)
